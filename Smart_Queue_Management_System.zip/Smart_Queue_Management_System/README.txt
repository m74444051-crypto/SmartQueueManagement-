Smart Queue Management System — Frontend

How to run:
1. Extract the ZIP file.
2. Open the Smart_Queue_Management_System folder.
3. Double-click index.html to open it in a browser.

Notes:
- This is a frontend-only demo.
- Patient data is saved in the browser's localStorage, not in a shared database.
- Voice recognition may require microphone permission and browser support.
